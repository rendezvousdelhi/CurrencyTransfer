package com.natwest.cct.controller;

import java.util.Date;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.cct.exception.CustomerProfileNotFoundException;
import com.natwest.cct.model.Customer;
import com.natwest.cct.service.ICustomerProfileService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@RequestMapping("api/v5")
public class CustomerLoginController {
	
	@Autowired
	private ICustomerProfileService custService;
	
	private ResponseEntity<?> responseentity;
	
	//added authentication code
	
	  @CrossOrigin(origins="*")
	    @PostMapping("/auth/login")	  
	  
		public ResponseEntity login(@RequestBody Customer cust)
		{
			Customer customer;
			try {
				customer = this.custService.findByEmailAndPassword(cust.getEmail(), cust.getPassword());
				if(customer==null)
				{
					return new ResponseEntity<String>("Invalid credentials",HttpStatus.UNAUTHORIZED);
				}
				
				String tok=generateToken(cust.getEmail());
				HashMap<String,String> mymap=new HashMap<String,String>();
				mymap.put("token", tok);
			   return new ResponseEntity<HashMap>(mymap,HttpStatus.OK);
			} catch (CustomerProfileNotFoundException e) {
				// TODO Auto-generated catch block
				return new ResponseEntity<String>("Invalid credentials",HttpStatus.UNAUTHORIZED);
			}
			
		} 
	  
		public String generateToken(String uname)
		
		{
			long expirytime=10_00_00_0000;
			
			return Jwts.builder().setSubject(uname)
					.setIssuedAt(new Date(System.currentTimeMillis()))
					.setExpiration(new Date(System.currentTimeMillis()+expirytime))
					.signWith(SignatureAlgorithm.HS256,"secretKey")
					.compact();
					
					
	    }

}
