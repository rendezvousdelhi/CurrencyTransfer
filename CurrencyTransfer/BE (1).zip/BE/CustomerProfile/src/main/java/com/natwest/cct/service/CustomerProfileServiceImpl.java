package com.natwest.cct.service;

import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.natwest.cct.exception.CustomerProfileAlreadyExistsException;
import com.natwest.cct.exception.CustomerProfileNotFoundException;
import com.natwest.cct.model.Customer;
import com.natwest.cct.repository.ICustomerProfileRepository;

@Service
public class CustomerProfileServiceImpl implements ICustomerProfileService {

	@Autowired
	private ICustomerProfileRepository custrepo;

	@Override
	public Customer saveCustomerProfile(Customer custObj) throws CustomerProfileAlreadyExistsException {
		List<Customer> optionalCustomer = this.custrepo.findByEmail(custObj.getEmail());

		Customer addedCustomer = null;

		if (!(optionalCustomer.isEmpty())) {
			System.out.println("Customer details Already Exists !!!! ");
			throw new CustomerProfileAlreadyExistsException();
		} else {
			if (custObj.getAccountno() == null) {
				Random rand = new SecureRandom();
				String accountNumber = "NW" + rand.nextInt(10000000);
				custObj.setAccountno(accountNumber);
			}

			addedCustomer = this.custrepo.save(custObj);
		}

		return addedCustomer;

	}

	// added code for authentication

	@Override
	public Customer findByEmailAndPassword(String email, String password) throws CustomerProfileNotFoundException {
		// Customer optionalcust=this.custrepo.findByEmailAndPassword(email, password);
		return this.custrepo.findByEmailAndPassword(email, password);
	}

	@Override
	public Customer updateCustomer(Customer custObj, String email) throws CustomerProfileNotFoundException {

		List<Customer> optionalcust = this.custrepo.findByEmail(email);

		Customer updatedcust = null;

		if (!(optionalcust.isEmpty())) {

			custObj.setPassword(optionalcust.get(0).getPassword());

			updatedcust = this.custrepo.save(custObj);
		} else {
			throw new CustomerProfileNotFoundException();
		}

		return updatedcust;

	}

	@Override
	public Customer getCustByEmail(String email) throws CustomerProfileNotFoundException {

		List<Customer> optionalcust = this.custrepo.findByEmail(email);

		Customer custObj = null;

		if (optionalcust.isEmpty()) {
			System.out.println("Customer Profile does not Exists !!!! ");
			throw new CustomerProfileNotFoundException();
		} else {
			custObj = optionalcust.get(0);
		}

		return custObj;
	}

}