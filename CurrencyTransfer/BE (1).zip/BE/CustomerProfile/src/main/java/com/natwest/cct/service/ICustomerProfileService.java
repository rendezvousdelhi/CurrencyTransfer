package com.natwest.cct.service;


import com.natwest.cct.exception.CustomerProfileAlreadyExistsException;
import com.natwest.cct.exception.CustomerProfileNotFoundException;
import com.natwest.cct.model.Customer;

public interface ICustomerProfileService 
{
	
	public Customer saveCustomerProfile(Customer custObj) throws CustomerProfileAlreadyExistsException;
	

	public Customer findByEmailAndPassword(String email, String password) throws CustomerProfileNotFoundException;


	public Customer updateCustomer(Customer custObj, String email) throws CustomerProfileNotFoundException;


	public Customer getCustByEmail(String email) throws CustomerProfileNotFoundException;


	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 /*
	 * public User updateUser(User userObj,int userId) throws UserNotFoundException;
	 * 
	 * public User getUserById(int userId) throws UserNotFoundException;
	 * 
	 * public List<User> getUserByName(String usern);
	 * 
	 * public List<User> getUserByKey(String usern);
	 * 
	 * public boolean deleteUserById(int userId) throws UserNotFoundException;
	 * 
	 * public List<User> getAllUsers();
	 */
	
}
