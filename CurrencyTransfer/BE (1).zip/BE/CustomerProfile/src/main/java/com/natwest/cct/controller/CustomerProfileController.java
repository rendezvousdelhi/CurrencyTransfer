package com.natwest.cct.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.natwest.cct.exception.CustomerProfileAlreadyExistsException;
import com.natwest.cct.exception.CustomerProfileNotFoundException;
import com.natwest.cct.model.Customer;
import com.natwest.cct.service.ICustomerProfileService;

@RestController
@RequestMapping("api/v5")

public class CustomerProfileController {

	@Autowired
	private ICustomerProfileService custService;

	private ResponseEntity<?> responseentity;

	@CrossOrigin(origins="http://localhost:3000")
	@PostMapping("/addCustomer")
	public ResponseEntity<?> addUserDetails(@RequestBody Customer custObj)
			throws CustomerProfileAlreadyExistsException {
		try {
			Customer customerDetails = this.custService.saveCustomerProfile(custObj);

			responseentity = new ResponseEntity(customerDetails, HttpStatus.CREATED);
		} catch (CustomerProfileAlreadyExistsException uaee) {
			System.out.println(uaee.getMessage());
			responseentity = new ResponseEntity("Customer Profile Already Exists !!!", HttpStatus.CONFLICT);
		}

		return responseentity;
	}
	
	@CrossOrigin(origins="http://localhost:3000")
	@PostMapping("/updateProfile/{email}")
	public ResponseEntity<?> updateUserDetails(@RequestBody Customer custObj, @PathVariable String email)
			throws CustomerProfileNotFoundException {
		try {
			Customer custDetails = this.custService.updateCustomer(custObj, email);

			responseentity = new ResponseEntity(custDetails, HttpStatus.CREATED);
		} catch (CustomerProfileNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Profile Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}

	@CrossOrigin(origins="http://localhost:3000")
	@GetMapping("/viewProfile/{email}")
	public ResponseEntity<?> getCustByEmail(@PathVariable String email) throws CustomerProfileNotFoundException {
		try {
			Customer custDetails = this.custService.getCustByEmail(email);

			responseentity = new ResponseEntity(custDetails, HttpStatus.OK);

		} catch (CustomerProfileNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Profile Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}

}
