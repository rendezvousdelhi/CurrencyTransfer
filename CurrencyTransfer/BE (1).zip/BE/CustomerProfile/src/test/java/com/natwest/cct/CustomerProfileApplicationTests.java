package com.natwest.cct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
