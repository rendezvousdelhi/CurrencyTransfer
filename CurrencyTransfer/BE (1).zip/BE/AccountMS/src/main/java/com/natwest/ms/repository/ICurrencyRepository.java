package com.natwest.ms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.natwest.ms.model.CurrencyEntity;

@Repository
public interface ICurrencyRepository extends JpaRepository<CurrencyEntity, String> {

	@Query(value="SELECT * FROM currency crr where crr.country like %:param1%", nativeQuery=true)
	public List<CurrencyEntity> findByCountry(@Param("param1") String country);
	
	@Query(value="SELECT * FROM currency crr where crr.currency like %:param1%", nativeQuery=true)
	public List<CurrencyEntity> findByCurrency(@Param("param1") String currency);
	
}
