package com.natwest.ms.service;

import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.Account;
import com.natwest.ms.model.AccountEntity;

public interface IAccountService 
{

	public Account getAccDetailsByEmail(String email) throws CustomerNotFoundException;

	public AccountEntity addMoney(AccountEntity accObj, String email) throws CustomerNotFoundException;	


	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 /*
	 * public User updateUser(User userObj,int userId) throws UserNotFoundException;
	 * 
	 * public User getUserById(int userId) throws UserNotFoundException;
	 * 
	 * public List<User> getUserByName(String usern);
	 * 
	 * public List<User> getUserByKey(String usern);
	 * 
	 * public boolean deleteUserById(int userId) throws UserNotFoundException;
	 * 
	 * public List<User> getAllUsers();
	 */
	
}
