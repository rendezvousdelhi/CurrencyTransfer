package com.natwest.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.Account;
import com.natwest.ms.model.AccountEntity;
import com.natwest.ms.model.Beneficiary;
import com.natwest.ms.model.FundTransfer;
import com.natwest.ms.service.IAccountService;
import com.natwest.ms.service.IBeneficiaryService;


@RestController
@RequestMapping("api/v7")
public class BeneficiaryController {
	
	@Autowired
	private IBeneficiaryService benfService;

	private ResponseEntity<?> responseentity;

	@CrossOrigin(origins="http://localhost:3000")
	@GetMapping("/getAllBeneficiaryDetails/{email}")
	public ResponseEntity<?> getBenfDetailsByEmail(@PathVariable String email) throws CustomerNotFoundException {
		try {
			List<Beneficiary> benfDetails = this.benfService.getBenfDetailsByEmail(email);

			responseentity = new ResponseEntity(benfDetails, HttpStatus.OK);

		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Beneficialy For Customer Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}
	
	@CrossOrigin(origins="http://localhost:3000")
	@GetMapping("/getAllCustomerDetails")
	public ResponseEntity<?> getAllUsersDetails() throws CustomerNotFoundException {
		try {
			List<AccountEntity> custDetails = this.benfService.getAllCustomerDetails();

			responseentity = new ResponseEntity(custDetails, HttpStatus.OK);

		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}
	
	@CrossOrigin(origins="http://localhost:3000")
	@PostMapping("/addBeneficiary/{email}")
	public ResponseEntity<?> addBeneficiaryDetails(@RequestBody Beneficiary benfObj, @PathVariable String email)
			throws CustomerNotFoundException {
		try {
			Beneficiary accDetails = this.benfService.addBeneficiaryDetails(benfObj, email);

			responseentity = new ResponseEntity(accDetails, HttpStatus.CREATED);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Profile Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}

	@CrossOrigin(origins="http://localhost:3000")
	@PostMapping("/fundTransfer")
	public ResponseEntity<?> fundTransfer(@RequestBody FundTransfer fnObj)
			throws CustomerNotFoundException {
		try {
			FundTransfer fundDetails = this.benfService.fundTransfer(fnObj);

			responseentity = new ResponseEntity(fundDetails, HttpStatus.CREATED);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Profile Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}

}
