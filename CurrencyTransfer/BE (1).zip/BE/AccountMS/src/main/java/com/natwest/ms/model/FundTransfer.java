package com.natwest.ms.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FundTransfer {

	  @JsonProperty("custEmail")
		private String custEmail;
	  
	  @JsonProperty("benfEmail")
		private String benfEmail;
	  
	  @JsonProperty("accountNo")
		private String accountNo;
	  
	  @JsonProperty("tranferAmount")
	  private double tranferAmount;
	  
		@JsonProperty("currency")
		private String currency;
	  
	  public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}



	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getBenfEmail() {
		return benfEmail;
	}

	public void setBenfEmail(String benfEmail) {
		this.benfEmail = benfEmail;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}



	public double getTranferAmount() {
		return tranferAmount;
	}

	public void setTranferAmount(double tranferAmount) {
		this.tranferAmount = tranferAmount;
	}

	@Override
	public String toString() {
		return "FundTransfer [custEmail=" + custEmail + ", benfEmail=" + benfEmail + ", accountNo=" + accountNo
				+ ", tranferAmount=" + tranferAmount + ", currency=" + currency + "]";
	}

	  
	  
}
