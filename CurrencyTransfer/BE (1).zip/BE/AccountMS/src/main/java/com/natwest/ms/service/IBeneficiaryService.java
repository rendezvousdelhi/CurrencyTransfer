package com.natwest.ms.service;

import java.util.List;

import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.AccountEntity;
import com.natwest.ms.model.Beneficiary;
import com.natwest.ms.model.FundTransfer;

public interface IBeneficiaryService 
{

	public List<Beneficiary> getBenfDetailsByEmail(String email) throws CustomerNotFoundException;

	public Beneficiary addBeneficiaryDetails(Beneficiary benfObj, String email) throws CustomerNotFoundException;

	List<AccountEntity> getAllCustomerDetails() throws CustomerNotFoundException;	
	
	public FundTransfer fundTransfer(FundTransfer fnObj) throws CustomerNotFoundException;		



	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 /*
	 * public User updateUser(User userObj,int userId) throws UserNotFoundException;
	 * 
	 * public User getUserById(int userId) throws UserNotFoundException;
	 * 
	 * public List<User> getUserByName(String usern);
	 * 
	 * public List<User> getUserByKey(String usern);
	 * 
	 * public boolean deleteUserById(int userId) throws UserNotFoundException;
	 * 
	 * public List<User> getAllUsers();
	 */
	
}
