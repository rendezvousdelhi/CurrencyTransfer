package com.natwest.ms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.Account;
import com.natwest.ms.model.AccountEntity;
import com.natwest.ms.service.IAccountService;


@RestController
@RequestMapping("api/v7")
public class AccountController {
	
	@Autowired
	private IAccountService accountService;

	private ResponseEntity<?> responseentity;
	
	@CrossOrigin(origins="http://localhost:3000")
	@GetMapping("/viewAccDetails/{email}")
	public ResponseEntity<?> getAccDetailsByEmail(@PathVariable String email) throws CustomerNotFoundException {
		try {
			Account accDetails = this.accountService.getAccDetailsByEmail(email);

			responseentity = new ResponseEntity(accDetails, HttpStatus.OK);

		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}
	
	@CrossOrigin(origins="http://localhost:3000")
	@PostMapping("/addMoney/{email}")
	public ResponseEntity<?> addMoney(@RequestBody AccountEntity accObj, @PathVariable String email)
			throws CustomerNotFoundException {
		try {
			AccountEntity accDetails = this.accountService.addMoney(accObj, email);

			responseentity = new ResponseEntity(accDetails, HttpStatus.CREATED);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
			responseentity = new ResponseEntity("Customer Profile Does Not Exists !!!", HttpStatus.NOT_FOUND);
		}

		return responseentity;
	}



}
