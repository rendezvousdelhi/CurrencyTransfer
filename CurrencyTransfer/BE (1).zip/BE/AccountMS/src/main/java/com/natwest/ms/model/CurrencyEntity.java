package com.natwest.ms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="currency")
public class CurrencyEntity {

	@Id
	@Column(name="country")
	private String country;
	
	@Column(name="currencycode")
	private String currency;
	
	@Column(name="conversionrate")
	private double conversionRate;
	
	@Column(name="symbol")
	private String symbol;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(double conversionRate) {
		this.conversionRate = conversionRate;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	@Override
	public String toString() {
		return "CurrencyEntity [country=" + country + ", currency=" + currency + ", conversionRate=" + conversionRate
				+ ", symbol=" + symbol + "]";
	}
	
	
	
}
