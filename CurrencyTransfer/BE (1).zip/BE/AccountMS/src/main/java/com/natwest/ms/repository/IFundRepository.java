package com.natwest.ms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.natwest.ms.model.AccountEntity;

public interface IFundRepository extends JpaRepository<AccountEntity, String>{

}
