package com.natwest.ms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="beneficiary")
public class Beneficiary 
{
	                                                                                      
	
	@Column(name="userEmailId")
	private String userEmailId;
	
	@Id
	@Column(name="benfEmailId")
	private String benfEmailId;
   	
	@Column(name="name")
	private String name;	

	
	@Column(name="accountno")
	private String accountno;
	

	

	public String getUserEmailId() {
		return userEmailId;
	}


	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}


	public String getBenfEmailId() {
		return benfEmailId;
	}


	public void setBenfEmailId(String benfEmailId) {
		this.benfEmailId = benfEmailId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAccountno() {
		return accountno;
	}


	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}



	@Override
	public String toString() {
		return "Beneficiary [userEmailId=" + userEmailId + ", benfEmailId=" + benfEmailId + ", name=" + name
				+ ", accountno=" + accountno + "]";
	}

	
	
}
