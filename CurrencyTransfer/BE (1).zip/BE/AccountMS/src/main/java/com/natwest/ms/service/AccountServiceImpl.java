package com.natwest.ms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.Account;
import com.natwest.ms.model.AccountEntity;
import com.natwest.ms.model.CurrencyEntity;
import com.natwest.ms.repository.IAccountRepository;
import com.natwest.ms.repository.ICurrencyRepository;

@Service
public class AccountServiceImpl implements IAccountService {

	@Autowired
	private IAccountRepository accRepo;
	
	@Autowired
	private ICurrencyRepository crrRepo;

	
	@Override
	public Account getAccDetailsByEmail(String email) throws CustomerNotFoundException {

		List<AccountEntity> optionalcust = this.accRepo.findByEmail(email);
		List<CurrencyEntity> optionalcrr=null;
		
		Account accObj = new Account();

		if (optionalcust.isEmpty()) {
			System.out.println("Customer Profile does not Exists !!!! ");
			throw new CustomerNotFoundException();
		} else {
			
			optionalcrr = this.crrRepo.findByCountry(optionalcust.get(0).getCountry());

			accObj.setEmail(optionalcust.get(0).getEmail());
			accObj.setName(optionalcust.get(0).getName());
			accObj.setAccountno(optionalcust.get(0).getAccountno());
			accObj.setBalance(optionalcust.get(0).getBalance());
			accObj.setMobileno(optionalcust.get(0).getMobileno());
			accObj.setCountry(optionalcrr.get(0).getCountry());
			accObj.setCurrencyCode(optionalcrr.get(0).getCurrency());
			accObj.setConversionRate(optionalcrr.get(0).getConversionRate());
			accObj.setSymbol(optionalcrr.get(0).getSymbol());
		
		}

		return accObj;
	}


	@Override
	public AccountEntity addMoney(AccountEntity accObj, String email) throws CustomerNotFoundException {
		
		List<AccountEntity> optionalcust = this.accRepo.findByEmail(email);

		AccountEntity updatedcust = null;

		if (!(optionalcust.isEmpty())) {
			double balance=optionalcust.get(0).getBalance();
			double addedMoney=accObj.getBalance();
			accObj.setBalance(balance+addedMoney);
			accObj.setPassword(optionalcust.get(0).getPassword());
			updatedcust = this.accRepo.save(accObj);
		} else {
			throw new CustomerNotFoundException();
		}

		return updatedcust;
	}

}