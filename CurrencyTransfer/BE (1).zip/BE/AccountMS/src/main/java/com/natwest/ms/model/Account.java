package com.natwest.ms.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Account
{
    @JsonProperty("email")
	private String email;
   	
    @JsonProperty("name")
	private String name=null;

    @JsonProperty("accountno")
	private String accountno=null;

    @JsonProperty("balance")
	private double balance=0;
	
    @JsonProperty("mobileno")
	private String mobileno=null;
	
    @JsonProperty("country")
	private String country=null;
	
    @JsonProperty("currencyCode")
	private String currencyCode=null;
	
    @JsonProperty("conversionRate")
	private double conversionRate=0.0;
	
    @JsonProperty("symbol")
	private String symbol=null;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAccountno() {
		return accountno;
	}

	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}



	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	

	public double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(double conversionRate) {
		this.conversionRate = conversionRate;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	@Override
	public String toString() {
		return "Account [email=" + email + ", name=" + name + ", accountno=" + accountno + ", balance=" + balance
				+ ", mobileno=" + mobileno + ", country=" + country + ", currencyCode=" + currencyCode
				+ ", conversionRate=" + conversionRate + ", symbol=" + symbol + "]";
	}



	
	
}
