package com.natwest.ms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.natwest.ms.model.Beneficiary;

@Repository
public interface IBeneficiaryRepository extends JpaRepository<Beneficiary, String> {

	@Query(value="SELECT * FROM beneficiary bn where bn.userEmailId like %:param1%", nativeQuery=true)
	public List<Beneficiary> findByUserEmailId(@Param("param1") String userEmailId);
	
	
}
