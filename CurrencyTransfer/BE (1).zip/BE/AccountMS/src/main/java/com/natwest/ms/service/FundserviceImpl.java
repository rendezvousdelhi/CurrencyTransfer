package com.natwest.ms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.AccountEntity;
import com.natwest.ms.model.Beneficiary;
import com.natwest.ms.model.CurrencyEntity;
import com.natwest.ms.model.FundTransfer;
import com.natwest.ms.repository.IAccountRepository;
import com.natwest.ms.repository.ICurrencyRepository;
import com.natwest.ms.repository.IFundRepository;

public class FundserviceImpl implements IFundService {
	
	

	

}
