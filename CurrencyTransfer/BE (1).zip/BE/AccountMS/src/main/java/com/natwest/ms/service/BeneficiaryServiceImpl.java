package com.natwest.ms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.natwest.ms.exception.CustomerNotFoundException;
import com.natwest.ms.model.Account;
import com.natwest.ms.model.AccountEntity;
import com.natwest.ms.model.Beneficiary;
import com.natwest.ms.model.CurrencyEntity;
import com.natwest.ms.model.FundTransfer;
import com.natwest.ms.repository.IAccountRepository;
import com.natwest.ms.repository.IBeneficiaryRepository;
import com.natwest.ms.repository.ICurrencyRepository;

@Service
public class BeneficiaryServiceImpl implements IBeneficiaryService {

	@Autowired
	private IBeneficiaryRepository benfRepo;

	@Autowired
	private IAccountRepository accRepo;
	
	@Autowired
	private ICurrencyRepository crrRepo;

	@Override
	public List<Beneficiary> getBenfDetailsByEmail(String email) throws CustomerNotFoundException {

		List<Beneficiary> optionalcust = this.benfRepo.findByUserEmailId(email);
		List<Beneficiary> benf = null;

		if (optionalcust.isEmpty()) {
			System.out.println("Beneficialy For Customer Does Not Exists !!!");
			throw new CustomerNotFoundException();
		} else {
			benf = optionalcust;

		}
		return benf;
	}

	@Override
	public List<AccountEntity> getAllCustomerDetails() throws CustomerNotFoundException {

		List<AccountEntity> custList = this.accRepo.findAllUsers();

		return custList;
	}

	@Override
	public Beneficiary addBeneficiaryDetails(Beneficiary benfObj, String email) throws CustomerNotFoundException {

		List<AccountEntity> optionalbenf = this.accRepo.findByEmail(email);

		Beneficiary updatedbenf = null;

		if (!(optionalbenf.isEmpty())) {
			updatedbenf = this.benfRepo.save(benfObj);
		} else {
			throw new CustomerNotFoundException();
		}

		return updatedbenf;
	}
	
	@Override	
	public FundTransfer fundTransfer(FundTransfer fnObj) throws CustomerNotFoundException {
		
		List<AccountEntity> optionalCust = this.accRepo.findByEmail(fnObj.getCustEmail());
		
		List<AccountEntity> optionalben = this.accRepo.findByEmail(fnObj.getBenfEmail());

		List<CurrencyEntity> optionalcrr = this.crrRepo.findByCountry(optionalben.get(0).getCountry());

		AccountEntity updatedcust = new AccountEntity();
		AccountEntity updatedben = new AccountEntity();

		FundTransfer fnobj1=new FundTransfer();

		if (!(optionalCust.isEmpty())) {
			   if (!(optionalben.isEmpty())) {
				    if (!(optionalcrr.isEmpty())) {
		
			double balance=optionalCust.get(0).getBalance();
			double transferMoney=fnObj.getTranferAmount();
			
			//updating customer details
			updatedcust.setEmail(optionalCust.get(0).getEmail());
			updatedcust.setName(optionalCust.get(0).getName());
			updatedcust.setCountry(optionalCust.get(0).getCountry());
			updatedcust.setAccountno(optionalCust.get(0).getAccountno());
			updatedcust.setBalance(balance-transferMoney);
			updatedcust.setMobileno(optionalCust.get(0).getMobileno());
			updatedcust.setPassword(optionalCust.get(0).getPassword());

			updatedcust=this.accRepo.save(updatedcust);
			
			//updating beneficiary details
			double benBalance=optionalben.get(0).getBalance();
			double currencyConversionRate=optionalcrr.get(0).getConversionRate();
			updatedben.setEmail(optionalben.get(0).getEmail());
			updatedben.setName(optionalben.get(0).getName());
			updatedben.setCountry(optionalben.get(0).getCountry());
			updatedben.setAccountno(optionalben.get(0).getAccountno());
			updatedben.setBalance((int) (benBalance+(transferMoney*currencyConversionRate)));
			updatedben.setMobileno(optionalben.get(0).getMobileno());
			updatedben.setPassword(optionalben.get(0).getPassword());

			updatedben=this.accRepo.save(updatedben);
			
			fnobj1.setCustEmail(optionalCust.get(0).getEmail());
			fnobj1.setBenfEmail(optionalben.get(0).getEmail());
			fnobj1.setTranferAmount(transferMoney);
			fnobj1.setAccountNo(optionalben.get(0).getAccountno());
			fnobj1.setCurrency(optionalcrr.get(0).getCurrency());
		
		}
			   }
		}else {
			throw new CustomerNotFoundException();
		}

		return fnobj1;
	
		
	}

}