import React, {useState} from 'react'
import { useFormik } from 'formik'
import * as yup from 'yup'
import { useNavigate } from "react-router-dom";
import Toast from 'react-bootstrap/Toast';
import './login.css';
import loginImg from '../Images/login3.jpeg';

export default function Login(props) {
    const [error, setError] = useState(false);
    const [msg, setMsg] = useState('');
    const [show, setShow] = useState(false);

    const loginUrl = 'http://localhost:8085/api/v5/auth/login';

    // const loginUrl = 'https://a993-2405-201-15-6806-951b-373f-5370-ad23.in.ngrok.io/api/v5/viewProfile/anu@abc.com';
    let navigate = useNavigate();
    const formik = useFormik({
        initialValues: {
            email: '',
            password: ''
        },
        onSubmit: values => {
            fetch(`${loginUrl}`, {

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(values)
            })
                .then(res => res.json())
                .then(data => {
                    console.log(data)
                    //if (data.status === 200) {
                        localStorage.setItem('token', data.token);
                        localStorage.setItem('loggedIn', true);
                        localStorage.setItem('email', values?.email);
                        props.handleLoginStateChange(true);
                        setShow(true);
                        setTimeout(() => {
                            navigate("/");
                        }, 2000);
                    // } else {
                    //     setError(true);
                    //     setMsg(data.message);
                    // }
                })
                .catch(err => {
                    console.error('Request failed', err)
                    setError(true);
                    setMsg(err.message);
                  })
        },
        validationSchema: yup.object().shape({
            email: yup.string()
                .email('Invalid Email Address')
                .required('Email cannot be left blank'),
            password: yup.string()
                .required('Password cannot be left blank')
        }),
    });
    return (
        <div className='log1'>
        <div className="container mt-3 mb-12">
            <div className="row">
            <div className="col-md-4">
                    <img src={loginImg} alt="Sign Up"></img>
                </div>
                <div className="col-md-4 offset-md-2">
                    <Toast onClose={() => setShow(false)} bg='success' show={show} delay={3000} autohide>
                        <Toast.Header>
                            <img
                            src="holder.js/20x20?text=%20"
                            className="rounded me-2"
                            alt=""
                            />
                            <strong className="me-auto">Success</strong>
                            <small>now</small>
                        </Toast.Header>
                        <Toast.Body>Logged in succesfully!!</Toast.Body>
                    </Toast>
                    <div className="bg-primary text-light py-3 text-center rounded">
                        <h2>Sign In</h2>
                    </div>
                    <form onSubmit={formik.handleSubmit} className="mb-3">
                        <div className="mt-2">
                            <input id="email" name="email" type="text" value={formik.values.email} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Email" />
                            {formik.errors.email && formik.touched.email ? <span className="text-danger">{formik.errors.email}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="password" name="password" type="password" value={formik.values.password} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Password" />
                            {formik.errors.password && formik.touched.password ? <span className="text-danger">{formik.errors.password}</span> : null}
                        </div>
                        <div className="mt-2 text-center">
                            <button id="btnLogin" type="submit" className="btn btn-primary">Submit</button>
                        </div>
                    </form>
                    {
                        error ? <div className="alert alert-danger" role="alert">
                            {msg}
                        </div> : null
                    }
                </div>
            </div>
        </div>
        </div>
    )
}