export const apiEndpoints = {
    profile: 'https://01e7-2405-201-15-6806-a502-1b11-870a-a364.in.ngrok.io/api/v5/',
    account: ''
}