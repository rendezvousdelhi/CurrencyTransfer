import React, { useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Header from "./Header/header";
import Register from './Register/register';
import Login from "./Login/login";
import Home from "./Home/home";
import FooterComp from "./Footer/footer";
import ViewUserProfile from "./UserProfile/ViewUserProfile/viewUserProfile";
import UpdateUserProfile from "./UserProfile/UpdateUserProfile/updateUserProfile";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLoginStateChange = (val) => {
    setIsLoggedIn(val);
  }

  const [uName, setuName] = useState("user");

  const handleuName = (val) => {
    setuName(val);
  }

  return (
    <div>
      <BrowserRouter>
        <Header isLoggedIn={isLoggedIn} handleLoginStateChange={handleLoginStateChange} uName={uName} />
            <Routes>              
              <Route path="/" element={<Home  isLoggedIn={isLoggedIn} uName={uName} handleuName={handleuName}
               />} />              
              <Route path="/register" element={<Register />} />
              <Route path="/login" element={<Login handleLoginStateChange={handleLoginStateChange}/>} />
              <Route path="/view-user-profile" element={<ViewUserProfile />} />
              <Route path="/update-user-profile" element={<UpdateUserProfile />} />
            </Routes>
          <FooterComp />  
      </BrowserRouter>
    </div>
  );
}

export default App;