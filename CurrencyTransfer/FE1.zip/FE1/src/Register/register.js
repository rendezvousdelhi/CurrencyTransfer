import { useFormik } from 'formik'
import * as yup from 'yup'
import React, {useState} from 'react'
import { useNavigate } from "react-router-dom";
import signUpImg from '../Images/signUp.jpeg';
import Toast from 'react-bootstrap/Toast';
import './register.css';
// import * as apiEndpoints from '../utils';

export default function Register() {
    const [show, setShow] = useState(false);
    const navigate = useNavigate();

    const addUserUrl = 'http://localhost:8085/api/v5/addCustomer';
     
    const formik = useFormik({
        initialValues: {
            name: '',
            email: '',
            country: '',
            mobileno: '',
            password: '',
            confirmpassword: ''
        },
        onSubmit: values => {

            // "{
            //     "email": "ayush@abc.com",
            //     "name": "Ayush",
            //     "country": "UK",
            //     "accountno": null,
            //     "balance": "0",
            //     "mobileno": "0987657331",
            //     "password": "ays@123"
            // }"

            const req = {
                email: values.email,
                name: values.name,
                country: values.country,
                accountno: null,
                balance: 0,
                mobileno: values.mobileno,
                password: values.password
            }
            fetch(`${addUserUrl}`, {

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                    // 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: JSON.stringify(req)
            })
                .then(res => res.json())
                .then(data => { 
                    console.log('User Registered Successfully') 
                    setShow(true);
                    setTimeout(() => {
                        navigate("/login");
                    }, 2000);
                })
        },
        onChange: values => {
            
            console.log("I am inside On Change ...")

        },
        validationSchema: yup.object().shape({
            name: yup.string()
                .min(3, 'Name is too short')
                .max(10, 'Name is too long')
                .required('Name cannot be left blank'),
            email: yup.string()
                .email('Invalid Email Address')
                .required('Email cannot be left blank'),
            password: yup.string()
                .required('Password cannot be left blank'),
            country: yup.string()
                .required('Country cannot be left blank'),
            mobileno: yup.string()
                .required('Mobile Number cannot be left blank')
                .min(10, 'Mobile Number length must be 10')
                .max(10, 'Mobile Number length must be 10'),
            confirmpassword: yup.string()
                .required('Confirm Password cannot be left blank')
                .test('confirmpassword', 'Password & confirm password should be same', function(cpass){
                    if(this.parent.password==cpass){
                        return true;
                    }
                    return false;
                })
        }),
    });
    return (
        <div className='reg'>
        <div className="container mt-3 mb-3">
            <div className="row">
                <div className="col-md-4">
                    <img src={signUpImg} alt="Sign Up"></img>
                </div>
                <div className="col-md-4 offset-md-2">
                    <Toast onClose={() => setShow(false)} bg='success' show={show} delay={3000} autohide>
                        <Toast.Header>
                            <img
                            src="holder.js/20x20?text=%20"
                            className="rounded me-2"
                            alt=""
                            />
                            <strong className="me-auto">Success</strong>
                            <small>now</small>
                        </Toast.Header>
                        <Toast.Body>Registered Succesfully!!</Toast.Body>
                    </Toast>
                    <div className="bg-primary text-light py-3 text-center rounded">
                        <h2>Sign Up</h2>
                    </div>
                    <form onSubmit={formik.handleSubmit} >
                        <div className="mt-2">
                            <input id="name" name="name" type="text" value={formik.values.name} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Name" />
                            {formik.errors.name && formik.touched.name ? <span className="text-danger">{formik.errors.name}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="email" name="email" type="text" value={formik.values.email} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Email" />
                            {formik.errors.email && formik.touched.email ? <span className="text-danger">{formik.errors.email}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="country" name="country" type="text" value={formik.values.country} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Country" />
                            {formik.errors.country && formik.touched.country ? <span className="text-danger">{formik.errors.country}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="mobileno" name="mobileno" type="text" value={formik.values.mobileno} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Mobile Number" />
                            {formik.errors.mobileno && formik.touched.mobileno ? <span className="text-danger">{formik.errors.mobileno}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="password" name="password" type="password" value={formik.values.password} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Password" />
                            {formik.errors.password && formik.touched.password ? <span className="text-danger">{formik.errors.password}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="confirmpassword" name="confirmpassword" type="password" value={formik.values.confirmpassword} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Confirm Password" />
                            {formik.errors.confirmpassword && formik.touched.confirmpassword ? <span className="text-danger">{formik.errors.confirmpassword}</span> : null}
                        </div>

                        <div className="mt-2 text-center">
                            <button type="submit" className="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
    )
}