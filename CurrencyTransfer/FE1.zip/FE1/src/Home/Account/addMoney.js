import { useFormik } from 'formik'
import * as yup from 'yup'
import React, {useEffect, useState} from 'react'
import Toast from 'react-bootstrap/Toast';

export default function AddMoney(props) {

    const [error, setError] = useState(false);
    const [msg, setMsg] = useState("");
    const [show, setShow] = useState(false);

    const email = localStorage.getItem('email');

    const [oldData, setOldData] = useState({});

    // const getAccDetailsUrl = 'http://localhost:8087/api/v7/viewAccDetails/Mark@abc.com';
    const getAccDetailsUrl = 'http://localhost:8087/api/v7/viewAccDetails/';
    // const addMoneyUrl = 'http://localhost:8087/api/v7/addmoney/Mark@abc.com';
    const addMoneyUrl = 'http://localhost:8087/api/v7/addMoney/';

    useEffect(() => {
        fetch(`${getAccDetailsUrl}${email}`, {
          method: "GET",
          headers: {
            'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
          },
        })
          .then((res) =>  res.json()
          )
          .then((data) => {
            console.log('addMoney', data)
            //if (data.status === 200) {
                formik.setFieldValue('currency', data?.currencyCode);
                formik.setFieldValue('accountno', data?.accountno);
                setOldData(data)
            // } else {
            //   setError(true);
            //   setMsg(data.message || "Failed to fetch user data");
            // }
          })
          .catch((err) => {
            console.error("Request failed", err);
            setError(true);
            setMsg(err.message || "Failed to fetch user data");
          });
      }, []);
     
    const formik = useFormik({
        initialValues: {
            currency: '',
            mode: '',
            amount: '',
            accountno: ''
        },
        onSubmit: values => {

            // const req = {   
            //     "email" :"ayush@abc.com",
            //     "name": "Ayush",
            //     "country": "UK",
            //     "accountno" :"NW6753212",
            //     "balance" :"500",
            //     "mobileno" :"0987657331",
            //     "password":"ays@123"   
            //     }

            const req = {
                email :oldData?.email,
                name: oldData?.name,
                country: oldData?.country,
                // mode: values.mode,
                // currency: values.currency,
                accountno: values.accountno,
                balance:+values.amount,
                mobileno : oldData?.mobileno,
                password: null
            }
            fetch(`${addMoneyUrl}${email}`, {

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(req)
            })
                .then(res => res.json())
                .then(data => { 
                    console.log('Amount Added Successfully') 
                    setShow(true);
                    setTimeout(() => {
                        props?.handleView("showAccountDetails");
                    }, 2000);
                })
                .catch((err) => {
                    console.error("Request failed", err);
                    setError(true);
                    setMsg(err.message || "Failed to fetch user data");
                  });
        },
        onChange: values => {
            
            console.log("I am inside On Change ...")

        },
        validationSchema: yup.object().shape({
            currency: yup.string(),
            mode: yup.string()
                .required('Mode cannot be left blank'),
            amount: yup.string()
                .required('Amount cannot be left blank'),
            accountno: yup.string()
                .required('Account Number cannot be left blank')
                // .min(10, 'Account Number length must be 10')
                // .max(10, 'Account Number length must be 10')
        }),
    });
    return (
        <div className="container mt-3 mb-3">
           
            <div className="row">
            {error ? (
                <div className="alert alert-danger" role="alert">
                    {msg}
                </div>
                ) : null}
                <div className="col-md-4 offset-md-4">
                    <Toast onClose={() => setShow(false)} bg='success' show={show} delay={3000} autohide>
                        <Toast.Header>
                            <img
                            src="holder.js/20x20?text=%20"
                            className="rounded me-2"
                            alt=""
                            />
                            <strong className="me-auto">Success</strong>
                            <small>now</small>
                        </Toast.Header>
                        <Toast.Body>Added Succesfully!!</Toast.Body>
                    </Toast>
                    <div className="bg-dark text-light py-3 text-center rounded">
                        <h2>Add Money</h2>
                    </div>
                    <form onSubmit={formik.handleSubmit} >
                       
                        <div className="mt-2">
                            <input id="accountno" readOnly={true} name="accountno" type="text" value={formik.values.accountno} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Account Number" />
                            {formik.errors.accountno && formik.touched.accountno ? <span className="text-danger">{formik.errors.accountno}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="mode" name="mode" type="text" value={formik.values.mode} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Mode" />
                            {formik.errors.mode && formik.touched.mode ? <span className="text-danger">{formik.errors.mode}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="currency" readOnly={true} name="currency" type="text" value={formik.values.currency} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Currency" />
                            {formik.errors.currency && formik.touched.currency ? <span className="text-danger">{formik.errors.currency}</span> : null}
                        </div>
                        <div className="mt-2">
                            <input id="amount" name="amount" type="text" value={formik.values.amount} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Amount" />
                            {formik.errors.amount && formik.touched.amount ? <span className="text-danger">{formik.errors.amount}</span> : null}
                        </div>
                        <div className="mt-2 text-center">
                            <button type="submit" className="btn btn-dark">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}