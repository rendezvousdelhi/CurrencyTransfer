import { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";

export default function ShowAccountDetails(props) {
  const [error, setError] = useState(false);
  const [msg, setMsg] = useState("");

  const [userData, setUserData] = useState({});

  // const profile= 'https://01e7-2405-201-15-6806-a502-1b11-870a-a364.in.ngrok.io/api/v5/viewProfile/anu@abc.com'
  const profile= 'http://localhost:8087/api/v7/viewAccDetails/'

  useEffect(() => {
    const email = localStorage.getItem('email');
    fetch(`${profile}${email}`, {
      method: "GET",
      headers: {
         "Content-Type": "application/json",
        //'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
      },
    })
      .then((res) => {
        // if (res.ok) {
        //     return res.json();
        // }
        //   throw new Error('Something went wrong');
       return res.json()
      })
      .then((data) => {
        console.log('ShowAccountDetails', data)
        localStorage.setItem('username',data.name);
       // if (data.status === 200) {
          setUserData(data)
          props.handleuName(data.name)
        // } else {
        //   setError(true);
        //   setMsg(data.message || "Failed to fetch user data");
        // }
      })
      .catch((err) => {
        console.error("Request failed", err);
        setError(true);
        setMsg(err.message || "Failed to fetch user data");
      });
  }, []);

  return (
    <div className="container mt-3 mb-3">
      <div className="row">
      {error ? (
          <div className="alert alert-danger" role="alert">
            {msg}
          </div>
        ) : null}
        <div className="col-md-4 offset-md-4"></div>
        <Table striped bordered hover variant="warning">
          <thead>
            <tr>
              {/* <th>Field Name</th> */}
              {/* <th>Value</th> */}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td> <strong>Name</strong></td>
              <td>{userData?.name}</td>
            </tr>
            <tr>
              <td><strong>Email</strong></td>
              <td>{userData?.email}</td>
            </tr>
            <tr>
              <td><strong>Country</strong></td>
              <td>{userData?.country}</td>
            </tr>
            <tr>
              <td><strong>Mobile Number</strong></td>
              <td>{userData?.mobileno}</td>
            </tr>
            <tr>
              <td><strong>Account Number</strong></td>
              <td>{userData?.accountno}</td>
            </tr>
            <tr>
              <td><strong>Currency</strong></td>
              <td>{userData?.currencyCode}</td>
            </tr>
            <tr>
              <td><strong>Balance</strong></td>
              <td>{userData?.balance}</td>
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
}
