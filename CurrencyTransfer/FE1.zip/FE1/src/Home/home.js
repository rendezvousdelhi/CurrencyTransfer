import * as React from "react";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import addBeneficiaryCard from "../Images/addBeneficiaryCard.png";
import beneficiariesCard from "../Images/beneficiariesCard.png";
import addMoneyCard from "../Images/addMoneyCard.png";
import accounDetailscard from "../Images/accounDetailscard.png";
import ShowAccountDetails from './Account/showAccountDetails';
import ShowBeneficiaries from './Beneficiary/showBeneficiaries';
import AddMoney from "./Account/addMoney";
import AddBeneficiaries from './Beneficiary/addBeneficiaries';
import './home.css';
import Carousel from 'react-bootstrap/Carousel';


function Home(props) {
  const [selectedTab, setSelectedTab] = React.useState("showAccountDetails");
  const {isLoggedIn} = props;

  const handleView = (view) => {
    setSelectedTab(view);
  };
  return (
    <div className="home1">
    <>
     {!isLoggedIn && <div className= "container mt-3 mb-3">
      {/* <h3>please login or create an account</h3> */} 
      <Carousel>
      <Carousel.Item interval={1000}>
        <img
          className="d-block w-100"
          src="./Images/s1.png"
          alt="First slide"
        />
        <Carousel.Caption>
          {/* <h3>First slide label</h3> */}
          {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={500}>
        <img
          className="d-block w-100"
          src="./Images/s2.png"
          alt="Second slide"
        />
        <Carousel.Caption>
          {/* <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      
    </Carousel>


      </div>}
      {isLoggedIn && <div className="container mt-3 mb-3">
        <div className="row">
          <div className="col-md-2  ">
            <Card style={{ width: "18rem", border : selectedTab === "showAccountDetails" ? "5px solid black" : "2px solid gray" }}>
              <Card.Img variant="top" src={accounDetailscard} />
              <Card.Body>
                <Button variant="primary" onClick={() => handleView("showAccountDetails")}>Account Details</Button>
              </Card.Body>
            </Card>
          </div>
          <div className="col-md-2 offset-md-1">
            <Card style={{ width: "18rem", border : selectedTab === "addMoney" ? "5px solid black" : "2px solid gray"  }}>
              <Card.Img variant="top" src={addMoneyCard} />
              <Card.Body>
                <Card.Title></Card.Title>
                <Card.Title></Card.Title>
                <Button variant="primary" onClick={() => handleView("addMoney")}>Add Money</Button>
              </Card.Body>
            </Card>
          </div>
          <div className="col-md-2 offset-md-1">
            <Card style={{ width: "18rem", border : selectedTab === "showBeneficiaries" ? "5px solid black" : "2px solid gray"  }}>
              <Card.Img variant="top" src={beneficiariesCard} />
              <Card.Body>
                <Button variant="primary" onClick={() => handleView("showBeneficiaries")}>
                Beneficiaries
                </Button>
              </Card.Body>
            </Card>
          </div>
          <div className="col-md-2 offset-md-1">
            <Card style={{ width: "18rem", border : selectedTab === "addBeneficiaries" ? "5px solid black" : "2px solid gray"  }}>
              <Card.Img variant="top" src={addBeneficiaryCard} />
              <Card.Body>
                <Button variant="primary" onClick={() => handleView("addBeneficiaries")}>Add Beneficiaries</Button>
              </Card.Body>
            </Card>
          </div>
        </div>
        {selectedTab === "showAccountDetails" && <div>
      <ShowAccountDetails {...props}/>
      </div>}
      {selectedTab === "addMoney" && <div>
      <AddMoney handleView={handleView} />
      </div>}
      {selectedTab === "showBeneficiaries" && <div>
      <ShowBeneficiaries handleView={handleView} />
      </div>}
      {selectedTab === "addBeneficiaries" && <div>
      <AddBeneficiaries handleView={handleView}/>
      </div>}
      </div>}
    </>
    </div>
  );
}

export default Home;
