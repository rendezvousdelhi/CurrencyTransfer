import React, {useEffect, useState} from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useFormik } from 'formik'
import * as yup from 'yup'
import Toast from 'react-bootstrap/Toast';

export default function FundTransfer(props) {

    const [error, setError] = useState(false);
    const [msg, setMsg] = useState("");
    const [show, setShow] = useState(false);

    const email = localStorage.getItem('email');

    const [userData, setUserData] = useState({});

    const getAccDetailsUrl = 'http://localhost:8087/api/v7/viewAccDetails/';
    const fundTransferUrl = 'http://localhost:8087/api/v7/fundTransfer';

    useEffect(() => {
        console.log('sssss', props)
        formik.setFieldValue('benfEmail',  props?.beneFundData?.benfEmailId);
        formik.setFieldValue('accountno', props?.beneFundData?.accountno,);

        fetch(`${getAccDetailsUrl}${email}`, {
          method: "GET",
          headers: {
            'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
          },
        })
          .then((res) =>  res.json()
          )
          .then((data) => {
            console.log('fundtrnsfer', data)
                formik.setFieldValue('currency', data?.currencyCode);
                setUserData(data)
          })
          .catch((err) => {
            console.error("Request failed", err);
            setError(true);
            setMsg(err.message || "Failed to fetch user data");
          });
      }, []);
      
     
    const formik = useFormik({
        initialValues: {
            currency: '',
            benfEmail: '',
            amount: '',
            accountno: ''
        },
        onSubmit: values => {
            console.log('onSubmit fund', values)
// 		private String custEmail;  

// 		private String benfEmail;	  
	
// 		private String accountNo;	  
	
// 		private int tranferAmount;   
// currency"

            const req = {
                custEmail :userData?.email,
                currency: userData?.currencyCode,
                benfEmail: values.benfEmail,
                accountNo: values.accountno,
                tranferAmount: parseFloat(values.amount)
            }

            
            fetch(`${fundTransferUrl}`, {

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(req)
            })
                .then(res => res.json())
                .then(data => { 
                    console.log('Fund Transfer Successfully') 
                    setShow(true);
                    setTimeout(() => {
                        props.handleFundtransferClose(true);
                    }, 2000);
                })
                .catch((err) => {
                    console.error("Request failed", err);
                    setError(true);
                    setMsg(err.message || "Failed to fetch user data");
                  });
        },
        onChange: values => {
            
            console.log("I am inside On Change ...")

        },
        validationSchema: yup.object().shape({
            currency: yup.string()
            .required('Currency cannot be left blank'),
            benfEmail: yup.string()
                .email('Invalid Email Address')
                .required('Email cannot be left blank'),
            amount: yup.string()
                .required('Amount cannot be left blank'),
            accountno: yup.string()
                .required('Account Number cannot be left blank')
        }),
    });

    return (
        <>
    
          <Modal show={props.showFundTranser} backdrop={'static'}>
            <Modal.Header closeButton={false}>
              <Modal.Title>Fund Transfer</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <div className="container mt-3 mb-3">
           
           <div className="row">
           {error ? (
               <div className="alert alert-danger" role="alert">
                   {msg}
               </div>
               ) : null}
               <div className="col-md-8 offset-md-2">
                   <Toast onClose={() => setShow(false)} bg='success' show={show} delay={3000} autohide>
                       <Toast.Header>
                           <img
                           src="holder.js/20x20?text=%20"
                           className="rounded me-2"
                           alt=""
                           />
                           <strong className="me-auto">Success</strong>
                           <small>now</small>
                       </Toast.Header>
                       <Toast.Body>Transferred Succesfully!!</Toast.Body>
                   </Toast>
                   <form>
                      
                       <div className="mt-2">
                           <input id="accountno" readOnly={true} name="accountno" type="text" value={formik.values.accountno} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Account Number" />
                           {formik.errors.accountno && formik.touched.accountno ? <span className="text-danger">{formik.errors.accountno}</span> : null}
                       </div>
                       <div className="mt-2">
                           <input id="benfEmail" readOnly={true} name="benfEmail" type="text" value={formik.values.benfEmail} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Email" />
                           {formik.errors.benfEmail && formik.touched.benfEmail ? <span className="text-danger">{formik.errors.benfEmail}</span> : null}
                       </div>
                       <div className="mt-2">
                           <input id="currency" readOnly={true} name="currency" type="text" value={formik.values.currency} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Currency" />
                           {formik.errors.currency && formik.touched.currency ? <span className="text-danger">{formik.errors.currency}</span> : null}
                       </div>
                       <div className="mt-2">
                           <input id="amount" name="amount" type="number" min="1" value={formik.values.amount} onBlur={formik.handleBlur} onChange={formik.handleChange} className="form-control form-control-sm" placeholder="Amount" />
                           {formik.errors.amount && formik.touched.amount ? <span className="text-danger">{formik.errors.amount}</span> : null}
                       </div>
                   </form>
               </div>
           </div>
       </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => props.handleFundtransferClose(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={formik.handleSubmit}>
                Submit
              </Button>
            </Modal.Footer>
          </Modal>
        </>
      );
    }