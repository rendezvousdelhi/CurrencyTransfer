import { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
import FundTransfer from './fundTransfer';

export default function ShowBeneficiaries(props) {
  const [error, setError] = useState(false);
  const [msg, setMsg] = useState("");
  const dummyData = [{name: '-', accountno:'-', benfEmailId: '-'}]
  const email = localStorage.getItem('email');

  const [beneficiaryData, setBeneficiaryData] = useState(dummyData);

  const [showFundTranser, setShowFundTransfer] = useState(false);
  const [beneFundData, setBeneFundData] = useState({});


  // const allBeneficiariesUrl = 'http://localhost:8087/api/v7/getAllBeneficiaryDetails/Mark@abc.com';
  const allBeneficiariesUrl = 'http://localhost:8087/api/v7/getAllBeneficiaryDetails/';

  useEffect(() => {
    fetch(`${allBeneficiariesUrl}${email}`, {
      method: "GET",
      headers: {
        // "Content-Type": "application/json",
        'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
      },
    })
      .then((res) => {
        // if (res.ok || res.status == 200) {
        //     return res.json();
        // }
        //   throw new Error('Something went wrong');
          return res.json()
      })
      .then((data) => {
          console.log('ShowBeneficiaries data', data)
        //if (data.status === 200) {
          setBeneficiaryData(data);
        // } else {
        //   setError(true);
        //   setMsg(data.message);
        // }
      })
      .catch((err) => {
        console.error("Request failed", err);
        setError(true);
        setMsg(err.message || "Failed to fetch user data");
      });
  }, []);

  const handleFundtransfer = (benefData) => {
    setShowFundTransfer(true);
    setBeneFundData(benefData);
  };

  const handleFundtransferClose = (val) => {
    setShowFundTransfer(false);
    setBeneFundData({});
    if(val) {
      props.handleView("showAccountDetails");
    }
  };

  return (
    <div className="container mt-3 mb-3">
      <div className="row">
          <h3>List of current beneficiaries added to your account</h3>
        <div className="col-md-4 offset-md-4"></div>
        {error ? (
          <div className="alert alert-danger" role="alert">
            {msg}
          </div>
        ) : null}
        <Table striped bordered hover variant="primary">
          <thead>
            <tr>
              <th>Beneficiary Name</th>
              <th>Account Number</th>
              <th>Beneficiary Email</th>
            </tr>
          </thead>
          <tbody>
              {beneficiaryData.map((ele) => {
                  return  <tr onClick={() => handleFundtransfer(ele)}>
                  <td>{ele?.name}</td>
                  <td>{ele?.accountno}</td>
                  <td>{ele?.benfEmailId}</td>
                </tr>
              })}
          </tbody>
        </Table>
      </div>
      {showFundTranser &&
      <FundTransfer showFundTranser={showFundTranser} beneFundData={beneFundData} handleFundtransferClose={handleFundtransferClose} />
}
    </div>
  );
}
