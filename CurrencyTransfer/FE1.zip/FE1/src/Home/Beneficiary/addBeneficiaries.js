import { useFormik } from "formik";
import * as yup from "yup";
import React, { useState } from "react";
import Toast from "react-bootstrap/Toast";

export default function AddBeneficiaries(props) {
  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);
  const [msg, setMsg] = useState("");
  const email = localStorage.getItem('email');

  // const addBeneficiariesUrl= 'http://localhost:8087/api/v7/addBeneficiary/Mark@abc.com';
  const addBeneficiariesUrl = "http://localhost:8087/api/v7/addBeneficiary/";

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      accountno: "",
    },
    onSubmit: (values) => {

    //   const req = {   
    //     userEmailId :"Mark@abc.com",
    //     benfEmailId: "ayush@abc.com",
    //     name: "Ayush Anand",
    //     accountno :"NW6753212"
    //     }

      const req = {
        userEmailId: email,
        benfEmailId: values.email,
        name: values.name,
        accountno: values.accountno,
      };

      fetch(`${addBeneficiariesUrl}${email}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(req),
      })
        .then((res) => res.json())
        .then((data) => {
          console.log("Beneficiary Registered Successfully");
          setShow(true);
          setTimeout(() => {
            props?.handleView("showBeneficiaries");
          }, 2000).catch((err) => {
            console.error("Request failed", err);
            setError(true);
            setMsg(err.message || "Failed to add beneficiary");
          });
        })
        .catch((err) => {
            console.error("Request failed", err);
            setError(true);
            setMsg(err.message || "Failed to fetch user data");
          });
    },
    onChange: (values) => {
      console.log("I am inside On Change ...");
    },
    validationSchema: yup.object().shape({
      name: yup
        .string()
        .min(3, "Name is too short")
        .max(22, "Name is too long")
        .required("Name cannot be left blank"),
      email: yup
        .string()
        .email("Invalid Email Address")
        .required("Email cannot be left blank"),
      accountno: yup
        .string()
        .required("Account Number cannot be left blank")
       // .min(10, "Account Number length must be 10")
       // .max(10, "Account Number length must be 10"),
    }),
  });
  return (
    <div className="container mt-3 mb-3">
      <div className="row">
        <h3>
          Please enter below details to add new beneficiary to your account
        </h3>
        {error ? (
          <div className="alert alert-danger" role="alert">
            {msg}
          </div>
        ) : null}
        <div className="col-md-4 offset-md-4">
          <Toast
            onClose={() => setShow(false)}
            bg="success"
            show={show}
            delay={3000}
            autohide
          >
            <Toast.Header>
              <img
                src="holder.js/20x20?text=%20"
                className="rounded me-2"
                alt=""
              />
              <strong className="me-auto">Success</strong>
              <small>now</small>
            </Toast.Header>
            <Toast.Body>Added Succesfully!!</Toast.Body>
          </Toast>
          <div className="bg-dark text-light py-3 text-center rounded">
            <h2>Add Beneficiary</h2>
          </div>
          <form onSubmit={formik.handleSubmit}>
            <div className="mt-2">
              <input
                id="name"
                name="name"
                type="text"
                value={formik.values.name}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Name"
              />
              {formik.errors.name && formik.touched.name ? (
                <span className="text-danger">{formik.errors.name}</span>
              ) : null}
            </div>
            <div className="mt-2">
              <input
                id="email"
                name="email"
                type="text"
                value={formik.values.email}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Email"
              />
              {formik.errors.email && formik.touched.email ? (
                <span className="text-danger">{formik.errors.email}</span>
              ) : null}
            </div>
            <div className="mt-2">
              <input
                id="accountno"
                name="accountno"
                type="text"
                value={formik.values.accountno}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Account Number"
              />
              {formik.errors.accountno && formik.touched.accountno ? (
                <span className="text-danger">{formik.errors.accountno}</span>
              ) : null}
            </div>
            <div className="mt-2 text-center">
              <button type="submit" className="btn btn-dark">
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
