import React, { useEffect, useState } from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import img1 from "../Images/Nat-logo.png";
import "./header.css";


function NavbarComp(props) {
  const {isLoggedIn, handleLoginStateChange, uName} = props;

  const handleLogout = () => {
    localStorage.setItem('loggedIn', false);
    localStorage.removeItem('email');
    handleLoginStateChange(false);
  }

  const username = localStorage.getItem('username') || 'user';
  
  return (
    <div className="head1">
    <Navbar>
      <Container>
        <Navbar.Brand className="nav-link" href="/">
          <img
            alt=""
            src={img1}
            width="30"
            height="30"
            className="d-inline-block align-top"
          />{" "}
          NatWest
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
          { (isLoggedIn) && <NavDropdown title="Profile" id="basic-nav-dropdown">
              <NavDropdown.Item href="/view-user-profile">View Profile</NavDropdown.Item>
              <NavDropdown.Item href="/update-user-profile">Update Profile</NavDropdown.Item>
            </NavDropdown>
            }
          </Nav>
         { !isLoggedIn &&  <Nav>
            <Nav.Link className="nav-link" href="/register"><strong>Register</strong></Nav.Link>
            <Nav.Link eventKey={2} className="nav-link" href="/login">
            <strong>Login </strong>
            </Nav.Link>
          </Nav>
         }
         { (isLoggedIn) &&  <Nav>
            <Nav.Link className="nav-link" href="#">Hello {uName} </Nav.Link>
            <Nav.Link eventKey={2} className="nav-link" href="/" onClick={handleLogout}>
              Logout
            </Nav.Link>
          </Nav>
         }
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </div>
  );
}

export default NavbarComp;


// bg="primary" variant="dark" expand="lg"