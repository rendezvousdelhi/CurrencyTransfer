import react from 'react';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import "./footer.css";

export default function FooterComp() {

    return(
      <div className="footer1">
        <Navbar>
        <Container>
            <Navbar.Brand className= "nav-link" href="#">For NatWest</Navbar.Brand>
            <Navbar.Toggle />
        <Navbar.Collapse className="justify-content-end">
          <Navbar.Text className= "nav-link">
            © 2023 Copyright: NatWest
          </Navbar.Text>
        </Navbar.Collapse>
        </Container>
    </Navbar>
    </div>
    )
}

// bg="dark" variant="dark" expand="lg"