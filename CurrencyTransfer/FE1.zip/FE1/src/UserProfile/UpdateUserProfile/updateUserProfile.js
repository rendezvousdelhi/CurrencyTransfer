import { useFormik } from "formik";
import * as yup from "yup";
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import updateImg from "../../Images/updateImg.jpeg";
import Toast from "react-bootstrap/Toast";
import "./update.css";

export default function UpdateUserProfile() {
  const [show, setShow] = useState(false);
  const navigate = useNavigate();

  const [error, setError] = useState(false);
  const [msg, setMsg] = useState("");

  const [userOldData, setOldData] = useState({});

  const profileUrl = "http://localhost:8085/api/v5/viewProfile/";
  const updateUrl = "http://localhost:8085/api/v5/updateProfile/";

  useEffect(() => {
    const email = localStorage.getItem("email");
    fetch(`${profileUrl}${email}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => res.json())
      .then((data) => {
        console.log("UpdateUserProfile user data", data);
       // if (data.status === 200) {
          setOldData(data);
          formik.setFieldValue("name", data.name);
          formik.setFieldValue("email", data.email);
          formik.setFieldValue("country", data.country);
          formik.setFieldValue("mobileno", data.mobileno);
        // } else {
        //   setError(true);
        //   setMsg(data.message || "Failed to fetch user data");
        // }
      })
      .catch((err) => {
        console.error("Request failed", err);
        setError(true);
        setMsg(err.message || "Failed to fetch user data");
      });
  }, []);

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      country: "",
      mobileno: "",
    },
    onSubmit: (values) => {
      const req = {
        email: userOldData?.email,
        name: values.name,
        country: values.country,
        accountno: userOldData?.accountno,
        balance: userOldData.balance,
        mobileno: values.mobileno,
      };
      fetch(`${updateUrl}${values.email}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(req),
      })
        .then((res) => res.json())
        .then((data) => {
          console.log("User Profile Updated Successfully");
          setShow(true);
          setTimeout(() => {
            navigate("/view-user-profile");
          }, 2000);
        })
        .catch((err) => {
          console.error("Request failed", err);
          setError(true);
          setMsg(err.message || "Failed to update");
        });
    },
    onChange: (values) => {
      console.log("I am inside On Change ...");
    },
    validationSchema: yup.object().shape({
      name: yup
        .string()
        .min(3, "Name is too short")
        .max(10, "Name is too long")
        .required("Name cannot be left blank"),
      email: yup
        .string()
        .email("Invalid Email Address")
        .required("Email cannot be left blank"),
      country: yup.string().required("Country cannot be left blank"),
      mobileno: yup
        .string()
        .required("Mobile Number cannot be left blank")
        .min(10, "Mobile Number length must be 10")
        .max(10, "Mobile Number length must be 10"),
    }),
  });
  return (
    <div className="update">
    <div className="container mt-3 mb-3">
      <div className="row">
        {error ? (
          <div className="alert alert-danger" role="alert">
            {msg}
          </div>
        ) : null}
        <div className="col-md-4">
          <img src={updateImg} alt="Update"></img>
        </div>
        <div className="col-md-4 offset-md-3">
          <Toast
            onClose={() => setShow(false)}
            bg="success"
            show={show}
            delay={3000}
            autohide
          >
            <Toast.Header>
              <img
                src="holder.js/20x20?text=%20"
                className="rounded me-2"
                alt=""
              />
              <strong className="me-auto">Success</strong>
              <small>now</small>
            </Toast.Header>
            <Toast.Body>Updated Succesfully!!</Toast.Body>
          </Toast>
          <div className="bg-dark text-light py-3 text-center rounded">
            <h2>Update User Profile</h2>
          </div>
          <form onSubmit={formik.handleSubmit}>
            <div className="mt-2">
              <input
                id="name"
                name="name"
                type="text"
                value={formik.values.name}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Name"
              />
              {formik.errors.name && formik.touched.name ? (
                <span className="text-danger">{formik.errors.name}</span>
              ) : null}
            </div>
            <div className="mt-2">
              <input
                id="email"
                name="email"
                readOnly={true}
                type="text"
                value={formik.values.email}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Email"
              />
              {formik.errors.email && formik.touched.email ? (
                <span className="text-danger">{formik.errors.email}</span>
              ) : null}
            </div>
            <div className="mt-2">
              <input
                id="country"
                name="country"
                type="text"
                value={formik.values.country}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Country"
              />
              {formik.errors.country && formik.touched.country ? (
                <span className="text-danger">{formik.errors.country}</span>
              ) : null}
            </div>
            <div className="mt-2">
              <input
                id="mobileno"
                name="mobileno"
                type="text"
                value={formik.values.mobileno}
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control form-control-sm"
                placeholder="Mobile Number"
              />
              {formik.errors.mobileno && formik.touched.mobileno ? (
                <span className="text-danger">{formik.errors.mobileno}</span>
              ) : null}
            </div>
            <div className="mt-2 text-center">
              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
    </div>
  );
}
